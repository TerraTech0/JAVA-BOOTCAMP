import org.w3c.dom.ls.LSOutput;

import java.util.*;

public class Basics {
    static Scanner data = new Scanner(System.in);

    public static void main(String[] args) {
//        quesiton1();
//        question2();
//        question3();
//        question4();
        question5();

//        swap();
//        revers();
//        reveres();

    }

    public static void quesiton1() {
        System.out.print("Enter first number: ");
        int first = data.nextInt();
        System.out.print("Enter second number: ");
        int second = data.nextInt();
        System.out.print("Enter third number: ");
        int third = data.nextInt();
        if (first > second && first > third) {
            System.out.println(first + " is the biggest");
        } else if (second > first && second > third) {
            System.out.println(second + " is the biggest");
        } else {
            System.out.println(third + " is the biggest");
        }
    }

    public static void question2() {
        System.out.println("Enter the word: ");
        String word = data.nextLine();
        System.out.println("Enter the index number: ");
        int index = data.nextInt();
        System.out.println(word.charAt(index));
    }

    public static void question3() {
//        System.out.println("Enter the numbers: ");
//        int number = data.nextInt();
//        int sum = 0;
//        while (number != -1) {
//            sum += number;
//            number = data.nextInt();
//        }
//        System.out.println("The sum of these numbers is: " + sum);
        //------------------------------------------------
//        System.out.println("Enter numbers: ");
//        int numbers = data.nextInt();
//        int sum = 0;
//        while(numbers != -1){
//            sum += numbers;
//            numbers = data.nextInt();
//        }
//        System.out.println(sum);

        System.out.println("Enter numbres: ");
        int number = data.nextInt();
        int sum = 0;
        while(number != -1){
            sum += number;
            number = data.nextInt();
        }
        System.out.println(sum);
    }

    public static void question4() {
        int[] numbers = {10, -21, 30, 31, -25};
        for (int i = 0; i < numbers.length; i++) {
//            System.out.println(numbers[i]);
            if (numbers[i] < 0) {
                System.out.println("Negative: " + numbers[i]);
            } else if (numbers[i] > 0) {
                System.out.println("Positive: " + numbers[i]);
            } else {
                System.out.println("Zero: " + numbers[i]);
            }
        }
    }

    public static void question5() {
        String[] words = {"Tuwaiq", "Bootcamp", "Student", "JAVA"};
//        String laragest = words[0];
//        for (String temp: words){
//            if (temp.length() > laragest.length()){
//                laragest = temp;
//            }
//        }
//        System.out.println(laragest);

//        String largest = words[0];
//        for (String temp : words){
//            if (temp.length() > largest.length()){
//                largest = temp;
//            }
//
//        }
//        System.out.println(largest);

//        String largest = words[0];
//
//        for (String word : words) {
//            if (word.length() > largest.length()) {
//                largest = word;
//            }
//        }
//        System.out.println(largest);
    }

    public static void swap() {

        ArrayList<Integer> arr = new ArrayList<Integer>();
        arr.add(50);
        arr.add(54);
        arr.add(51);
        arr.add(68);
        arr.add(90);
        arr.add(100);

        System.out.println("Befor Swapping" + arr);

        Collections.swap(arr, 0, 5);

        System.out.println("After swapping");
        System.out.println(arr);
    }

    public static void revers() {
//        String word = "Hello world";
//
//        StringBuilder stringBuilder = new StringBuilder(word);
//        stringBuilder.reverse();
//        String reversed = stringBuilder.toString();
//        System.out.println(reversed);







        String word = "hello world!";
        String reve = "";

        for (int i = word.length() -1 ; i >= 0 ; i--) {
            reve += word.charAt(i);
        }
        System.out.println(reve);





//        for (int i = word.length() -1 ; i >= 0 ; i--) {
//            reve += word.charAt(i);
//
//        }
//        System.out.println(reve);





//        int numbers = 54321;
//        String numberStr = Integer.toString(numbers);
//        String rever = "";
//
//        for (int i = numberStr.length() -1 ; i>=0 ; i--) {
//            rever = rever + numberStr.charAt(i);
//
//        }
//
//        System.out.println(rever);



//        int num = 1234567890;
//        String numStr = Integer.toString(num);
//        String rev = "";
//        for (int i = numStr.length() - 1; i>=0 ; i--) {
//            rev += numStr.charAt(i);
//        }
//        System.out.println(rev);
//        int num = 1245;
//        String numStr = Integer.toString(num);
//        String rev = "";
//        for (int i =numStr.length() -1 ; i >=0 ; i--) {
//            rev += numStr.charAt(i);
//        }
//        System.out.println(rev);
    }
    public static void reveres(){
        int[] arr={1,2,3,4,5};
        for (int i = arr.length -1; i >= 0; i--) {
            System.out.print(arr[i]);
        }


    }

}

