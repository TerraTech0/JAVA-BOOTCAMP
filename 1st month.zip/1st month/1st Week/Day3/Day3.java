import java.util.Scanner;

public class Day3 {
    static Scanner data = new Scanner(System.in);
    public static void main(String[] args) {
//        forloop();
//        forloopevennumber();
//        forloopoddnumber();
//        whileloop();
//        challenge();
//        dowhile();

    }
    public static void forloop(){
        //fori << shortcut to write for loop!
        //encrement & decrement
        int i;
        for (i = 10; i >= 0; i--) {
            System.out.println(i);
        }
    }
    public static void forloopevennumber(){

        //for loop:
//        print the even numbers:
        for (int i = 0; i < 100; i=i+2) {
            System.out.println(i);

        }

    }
    public static void forloopoddnumber(){
        //print the odd numbers:
        for (int j = 1; j < 100; j=+2) {
            System.out.println(j);
        }
    }
    public static void whileloop(){
        //while loop:
        int i = 0;
        while( i < 100){
            System.out.println(i);
            i+=2;
        }

        int j = 100;
        while(j >= 0){
            System.out.println(j);
            j--;
        }
    }
    // take the data from the user (data = numbers)
    // the quite number -1
    // if i entered another number it show me please enter number to quite
    // when i enter the right number it will add all numbers that i entered before
    public static void challenge(){
        int number;
        int sum = 0;
        System.out.println("Please enter number or -1 to quite: ");
        number = data.nextInt();

        while(number != -1){
            sum = sum + number;
            //Check why this statement doesn't match the statement above??
//            sum += number;
            System.out.println("Please enter number or -1 to quite: ");
            number  = data.nextInt();
        }
        System.out.println(sum);
    }

    //Do While
    public static void dowhile(){
        int age;
        System.out.println("enter your age");
        age = data.nextInt();
        do{
            System.out.println("sorry you under age");
        break;
        }while(age < 13);


    }




        //NOTES
    // difference between break and continue :
    // break >> get out from the entier loop
    //continue >> skip the current loop and continue
}