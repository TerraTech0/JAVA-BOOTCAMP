import java.util.Scanner;

public class Intro {
    public static void main(String[] args)
    {
        //Day1
//        System.out.println("Hello world!");








    }
}