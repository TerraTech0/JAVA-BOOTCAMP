import java.util.Scanner;

public class Day2 {
    public static void main(String[] args) {
        //Day2
        // Data Types
//        String name = "ali";
//        int age = 12;
//        float flt = 1.342324f;
//        double dbl = 135.1234234;
//        char grade = 'A';
//        boolean trueorfalse = true;
//        byte byt = -120;
//        long llong = 12564561231654L;
//        System.out.println(name +" "+ age +" "+flt+" "+dbl+" "+grade+" "+trueorfalse+" "+byt+" "+llong);


//        int num1 = 10;
//        int num2 = 15;
//        System.out.println(num1 + num2);
//
//        String name1 = "Abdulrahman";
//        String name2 = "Ghazwani";
//        System.out.println(name1 +" "+ name2);

        //Arithmetic Operators

//        int add = num1 + num2;
//        int sub = num1 - num2;
//        int mult = num1 * num2;
//        int div = num1 / num2;
//        int mod = num1 % num2;
//
//        System.out.println(mod);

        // doesn't work as expect!!!
//        System.out.println("add" +(num1 + num2));


        // Comparison Operators

//        System.out.println(num1 > num2);
//        System.out.println(num1 < num2);
//        System.out.println(num1 >= num2);
//        System.out.println(num1 <= num2);
//        System.out.println(num1 == num2);
//        System.out.println(num1 != num2);

        // Logic Operators
//        int num1 = 10;
//        int num2 = 15;
//        int num3 = 20;
//        //And
//        System.out.println((num1 > num2) && (num3 < num2));
//        //Or
//        System.out.println((num1 >= num2) || (num2 == num2));
//        //Not
//        System.out.println(!(num1 >= num2));

        //primitive and non-primitive

        //Non-primitive:
        //String:
        //length >> return int
        //equals >> return (true, false)

//        String name = " abdulrhaman ";
//        System.out.println(name.length());
//        System.out.println(name.toUpperCase());
//        System.out.println(name.trim());
//        System.out.println(name.charAt(5));
//        System.out.println(name.compareTo("Abdulrhaman"));
//        System.out.println(name.concat("Ghzwani"));
//
//        String nametTrim = name.trim();
//        System.out.println(nameTrim);
//
//        System.out.println(name.replace("a", "A"));
//        System.out.println(name.startsWith(" abd"));
//        System.out.println(name.endsWith("man "));
//        System.out.println(name.toLowerCase());
//        System.out.println(name.getBytes());


        //Scanner
        Scanner data = new Scanner(System.in);
//        System.out.println("please enter your name: ");
//        String name = data.next();
//        System.out.println("please enter your age: ");
//        int age = data.nextInt();
//        System.out.println("Welcome "+name+" you are "+age+" years old");


//        System.out.println("Enter the first number: ");
//        int num1 = data.nextInt();
//        System.out.println("Enter the second number: ");
//        int num2 = data.nextInt();
//        System.out.println("The sum of two numbers is: " + (num1 + num2));


        //Conditions-Statement
//        System.out.println("please enter your grade: ");
//        float grade = data.nextFloat();
//        if (grade >= 95 && grade <=100){
//            System.out.println("your grade is A+");
//        }
//        else if(grade >= 90 && grade <=94){
//            System.out.println("your grade is A");
//        }else if(grade >= 85 && grade <=89){
//            System.out.println("your grade is B+");
//        }else if(grade >= 80 && grade <=84){
//            System.out.println("your grade is B");
//        }else if(grade >= 75 && grade <=79){
//            System.out.println("your grade is C+");
//        }else if(grade >= 70 && grade <=74){
//            System.out.println("your grade is C");
//        }else if(grade >= 65 && grade <=69){
//            System.out.println("your grade is D+");
//        }else if(grade >= 60 && grade <=64){
//            System.out.println("your grade is D");
//        }else if(grade >= 0 && grade <=59){
//            System.out.println("Fail");
//        }
//        else {
//            System.out.println("Out Of Range");
//        }


        //Question

//        The difference between next and nextLine() is when i want to write with spaces i use next() if i want the entier string i use nextLine()
        System.out.println("please enter your username");
//        String username = data.next();
//        String username = data.nextLine();
//        System.out.println("please enter your password");
//        String password = data.next();
//        System.out.println(username);

//        if (password.length()<8){
//            System.out.println("Week password");
//        }else {
//            System.out.println("Strong password");
//        }

//        System.out.println("please enter your username: ");
//        String username = data.next();
//        System.out.println("please enter your password: ");
//        String password = data.next();
//        System.out.println("please enter a number: ");
//        int number = data.nextInt();
//
//        switch (number){
//            case 1:
//                System.out.println("your usename is: "+ username);
//                break;
//            case 2:
//                System.out.println("your passowrd is: " + password);
//                break;
//            default:
//
//        }
    }
}