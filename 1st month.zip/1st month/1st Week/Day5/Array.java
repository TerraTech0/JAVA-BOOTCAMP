import java.util.Arrays;

public class Array {
    public static void main(String[] args) {
        array();
    }

    public static void array() {
        String[] arr = {"Cat","Dog","Camel","Panda"};
//        System.out.println(Arrays.toString(arr));
        int firstIndex = 2;
        int secondIndex = 3;
        String temp = arr[firstIndex];

        arr[firstIndex] = arr[secondIndex];
        arr[secondIndex] = temp;
        System.out.println(Arrays.toString(arr));

    }



}