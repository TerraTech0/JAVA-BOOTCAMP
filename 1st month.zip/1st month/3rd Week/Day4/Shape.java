public interface Shape {

    String name = "Shape";
    String getType();  // method doesn't have a body ..!
    double getArea(); //this how to write a method in interface, has no body.


}
