public class Night implements Classes{
    private String teacher;
    private String classNumber ;
    private int hours;
    private int overTime;

    public Night(String teacher, String classNumber, int hours, int overTime) {
        this.teacher = teacher;
        this.classNumber = classNumber;
        this.hours = hours;
        this.overTime = overTime;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public String getClassNumber() {
        return classNumber;
    }

    public void setClassNumber(String classNumber) {
        this.classNumber = classNumber;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public int getExtraHours() {
        return overTime;
    }

    public void setExtraHours(int extraHours) {
        this.overTime = overTime;
    }

    @Override
    public String getType() {
        return "Night";
    }

    @Override
    public String info() {
        return teacher + classNumber;
    }

    @Override
    public int getHours() {
        return hours;
    }

    @Override
    public int Salary() {
        return hours * 60;
    }

    @Override
    public int overTime() {
        System.out.println(overTime);
        int total = overTime + hours;
        System.out.println("Hours after overTime: "+ total);
        return overTime();
    }
}
