public class Main {
    public static void main(String[] args) {

        //private final int hours;
        //used in variables and methods
        //can't be overrided
        //final => it will never change
//        Teacher teacher = new Teacher(); //this class can't be object coz it's abstract class

        FullTime fullTime = new FullTime("1","Ahmed","0569548245","ahmed@example.com",5600, 10.5);

        System.out.println(fullTime.getId()+"\n"+fullTime.getName()+"\n"+fullTime.getEmail()+"\n"+fullTime.getNumber()+"\n"+fullTime.getSalary()+"\n"+fullTime.getBouns());
        fullTime.setSalary(500);
        System.out.println(fullTime.getSalary());
        System.out.println("================= PartTime ==============");
        PartTime partTime = new PartTime("2","partTime","05454845","email.com",30);
        System.out.println(partTime.getId()+"\n"+partTime.getName()+"\n"+partTime.getNumber()+"\n"+partTime.getEmail()+"\n"+partTime.getHours()+"\n"+partTime.getSalary());


        System.out.println("===============Square============");
        Square square = new Square(5);
        System.out.println("The area of square is: "+ square.getArea());

        System.out.println("===============Rectangle=========");
        Rectangle rectangle = new Rectangle(25,11);
        System.out.println("The area of rectangle is: "+rectangle.getArea() );


        System.out.println("=================== Morning Class =============");
        Morning morning = new Morning("Mohammed","Lab1", 8,5);
        System.out.println("Class: "+morning.getType()+"\nTeacher Name: "+morning.getTeacher()+"\nClass Name: "+morning.getClassNumber()+"\nHours: "+morning.getHours()+"\nExtra Hours: "+morning.overTime());
        System.out.println("Salary is: "+morning.Salary());

        System.out.println("=================== Night Class =============");
        Night night = new Night("Ahmed", "Lab2", 6,4);
        System.out.println("Class: "+night.getType()+"\nTeacher Name: "+night.getTeacher()+"\nClass Name: "+night.getClassNumber()+"\nHours: "+night.getHours()+"\nExtra Hours: "+night.overTime());
        System.out.println("Salary is: "+night.Salary());

    }


}
