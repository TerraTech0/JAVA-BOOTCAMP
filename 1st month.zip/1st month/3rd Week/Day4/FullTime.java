public class FullTime extends Teacher{
    private int salary;
    private double bouns;
    public FullTime(String id, String name, String number, String email, int salary, double bouns) {
        super(id, name, number, email);
        this.salary = salary;
        this.bouns = bouns;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public double getBouns() {
        return bouns;
    }

    public void setBouns(double bouns) {
        this.bouns = bouns;
    }

    @Override
    public void setSalary() {
        salary += salary * bouns / 100;
//        super.setSalary(salary);
    }
}
