public class Morning implements Classes{
    private String teacher ;
    private String classNumber;
    private int hours;
    private int overTime;

    public Morning(String teacher, String classNumber, int hours, int overTime) {
        this.teacher = teacher;
        this.classNumber = classNumber;
        this.hours = hours;
        this.overTime = overTime;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public String getClassNumber() {
        return classNumber;
    }

    public void setClassNumber(String classNumber) {
        this.classNumber = classNumber;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public int getOverTime() {
        return overTime;
    }

    public void setOverTimes(int overTime) {
        this.overTime = overTime;
    }

    @Override
    public String getType() {
        return "Morning";
    }

    @Override
    public String info() {

        return teacher + classNumber ;
    }

    @Override
    public int getHours() {
        return hours;
    }

    @Override
    public int Salary() {
        return hours * 60;
    }

    @Override
    public int overTime() {
        return overTime;
    }


}
