public class PartTime extends Teacher{
    private int hours;
//    private int res;
    public PartTime(String id, String name, String number, String email, int hours) {
        super(id, name, number, email);
        this.hours = hours;
//        this.res = res;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    @Override
    public void setSalary() {

    }

    @Override
    public int getSalary() {

        return hours * 30;
    }
//    public String getJobTitle(){} //can't be override coz its final

}
