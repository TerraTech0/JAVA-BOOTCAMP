public interface Classes {


    String getType();

    String info();
    int getHours();

    //Add logic methods here..
    int Salary();
    int overTime();



}
