import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {
    static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {

        List<Person> people = new ArrayList<>();

        int times = 5;
        int count = 0;
        while(count < times){
        try {
            for (int i = 0; i < times; i++) {
                System.out.print("Please Enter your name: ");
                String name = input.nextLine();
                System.out.print("Please Enter your age: ");
                int age = input.nextInt();

                Person person = new Person(name, age);
                people.add(person);
                input.nextLine();
                count++;

//            System.out.println("Person's name: "+person.getName()+"\nPerson's age: "+person.getAge());
            }
        }catch (InputMismatchException e){
            System.out.println("Please enter the right input: ");
            input.nextLine();
        }catch (Exception e1){
            System.out.println(e1.getMessage());
            input.nextLine();
        }

        System.out.println("=================================");
        for (Person person : people) {
            System.out.println("Person name: " + person.getName());
            System.out.println("Person age: " + person.getAge());
            System.out.println("=============================");
        }
}

    }
}
