public interface Vehicle {

    double calculateRentalCost();
    void displayDetails();

}
