import java.util.Scanner;

public class OOP {
    static Scanner data = new Scanner(System.in);
    public static void main(String[] args) {

        //signes are important:
        // -firstName > private
        // +firstName > public

//        Student student = new Student();
//        Student student1 = new Student();
//
//        //==============================
//        student.setId("1");
//        student.setFirstName("Ahmed");
//        student.setLastName("Ali");
//        student.setEmail("A.Ali@gmail.com");
//        student.setPhoneNumber("0555555550");
//        student.setAge(19);
//        System.out.println("The id is: "+student.getId() + "\nStudent first name is:"+student.getFirstName()+ "\nStudent lastName is: "+student.getLastName() +
//                "\nStudent email is: "+student.getEmail() + "\nStudent phoneNumber is: "+student.getPhoneNumber()+ "\nStudent age is: "+student.getAge());

//        System.out.println("============================");
//
//        student1.setId("2");
//        student1.setFirstName("Khaled");
//        student1.setLastName("Mohammed");
//        student1.setEmail("K.Mohammedgmail.com");
//        student1.setPhoneNumber("0537313508");
//        student1.setAge(12);
//
//        System.out.println("The id is: "+student1.getId() + "\nStudent first name is:"+student1.getFirstName()+ "\nStudent lastName is: "+student1.getLastName() +
//                "\nStudent email is: "+student1.getEmail() + "\nStudent phoneNumber is: "+student1.getPhoneNumber()+ "\nStudent age is: "+student1.getAge());
//        System.out.println("The id is: "+student.Id + "\nStudent first name is:"+student.firstName + "\nStudent lastName is: "+student.lastName +
//        "\nStudent email is: "+student.email + "\nStudent phoneNumber is: "+student.phoneNumber + "\nStudent age is: "+student.age);
//        student1.setId("10");
//        student.setFirstName("Abdurlahman");
////        student.firstName = "Abdulrahman";
////        student.lastName = "Ali";
//        student1.setLastName("Ali");
////        student.email = "aa@gmail.com";
//        student1.setEmail("A.Ali@gmail.com");
////        student.phoneNumber = "055555555";
//        student1.setPhoneNumber("055555555");
////        student.age = 14;
//        student1.setAge(14);

//        System.out.println("\nid is: "+student1.Id+"\nfirst name is: "+student1.firstName+"\nlast name is: "+ student1.lastName + "\nemail is: " + student1.email +
//                "\nage is: "+ student1.age +"\nphone number is: "+ student1.phoneNumber);
//
//        System.out.println("\nid is: "+student2.Id+"\nfirst name is: "+student2.firstName+"\nlast name is: "+ student2.lastName + "\nemail is: " + student2.email +
//                "\nage is: "+ student2.age +"\nphone number is: "+ student2.phoneNumber);
//
//        System.out.println("\nid is: "+student3.Id+"\nfirst name is: "+student3.firstName+"\nlast name is: "+ student3.lastName + "\nemail is: " + student3.email +
//                "\nage is: "+ student3.age +"\nphone number is: "+ student3.phoneNumber);


        System.out.println("====== Account =======");
        Account account1 = new Account();

        account1.setId("1");
        account1.setName("Ahmed");
        account1.setBalance(1000);
        System.out.println("ID: "+account1.getId()+"\nName: "+account1.getName()+"\nBalance: "+ account1.getBalance());



        int credit = account1.credit(1000);
        System.out.println("Credit have: "+credit);
//        System.out.println("Enter the debit amount: ");
//        int deb = data.nextInt();
//        System.out.println("Debit is: "+ 15);
        System.out.println("After Debit:" + account1.debit(15));
//        System.out.println("Enter the transfer amount: ");
//        int trans = data.nextInt();
//        System.out.println("The transfer amount is: "+trans);
//        System.out.println("After Transfer: "+ account1.transferTo(trans));
//        System.out.println("After Transfer: "+account1.transferTo(1000,50));

        System.out.println("====== Employee =======");
        Employee employee = new Employee();

        employee.setId("1");
        employee.setName("Waleed");
        employee.setSalary(15000);
        System.out.println(employee.getId() + employee.getName()+employee.getSalary());





    }

}
