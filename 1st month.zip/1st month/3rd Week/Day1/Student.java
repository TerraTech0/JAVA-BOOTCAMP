public class Student {

    //this is attributes >> صفات
   private String Id;  //if i don't do any calculation on this number it doesn't need to int >> so it will be String
   private String firstName;
   private String lastName;
   private String email;
   private String phoneNumber;
   private int age;

    Student(){  //specail method >> constractor

    }
//    Student(String Id, String firstName, String lastName, String email, int age , String phoneNumber){
//        this.Id = Id;
//        this.firstName = firstName;
//        this.lastName = lastName;
//        this.email = email;
//        this.age = age;
//        this.phoneNumber = phoneNumber;
//
//    }
    //get
    public String getId(){

        return Id;
    }

    public void setId(String Id){
        this.Id = Id;
    }
    public String getFirstName(){
        return firstName;
    }
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    public String getLastName(){
        return lastName;
    }
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        if (checkMail(email)){
            this.email = email;
        }else {
            System.out.println("invalid email.");
        }

    }
    public String getPhoneNumber (){
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber){
        if (checkPhon(phoneNumber)){
            this.phoneNumber = phoneNumber;

        }else{
            System.out.println("invalid phone number");
        }
    }
public int getAge(){
        return age;
    }
    public void setAge(int age){
        if (checkAge(age)){
            this.age = age;
        }else {
            System.out.println("under age.");
        }
    }



    public boolean checkPhon(String phone){
        return phone.length() == 10;
    }

    public boolean checkAge(int age){
        return age > 18;
    }
    public boolean checkMail(String email){
        return email.contains("@");
    }
//    public

}
