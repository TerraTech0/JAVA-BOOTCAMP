public class Square implements Shape{


    @Override
    public void form() {
        System.out.println("*******");
        System.out.println("*******");
        System.out.println("*******");
    }
}