public class Draw {

    public void draw (Shape square){

//        return square.toString();
    }
}
