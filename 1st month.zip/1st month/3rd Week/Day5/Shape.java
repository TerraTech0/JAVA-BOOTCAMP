public interface Shape {

    void form();
}