public class Main {
    public static void main(String[] args) {


        Shape square = new Square();
        Shape triangle = new Triangle();
        Shape rectangle = new Rectangle();

        Draw d = new Draw();
//        d.square
        square.form();
        System.out.println("\n================================");
        triangle.form();
        System.out.println("\n================================");
        rectangle.form();


    }
}