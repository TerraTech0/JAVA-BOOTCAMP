public class Rectangle implements Shape{
    @Override
    public void form() {
        System.out.println("************************");
        System.out.println("************************");
        System.out.println("************************");
        System.out.println("************************");
    }
}