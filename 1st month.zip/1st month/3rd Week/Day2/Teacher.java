public class Teacher extends Person{
    private int salary;
    private int experaiceYears;

    public Teacher(String id, String name, String email, String phoneNumber, int age, int salary, int experaiceYears) {
        super(id, name, email, phoneNumber, age);
        this.salary = salary;
        this.experaiceYears = experaiceYears;
    }
//
//    public Teacher(String id, String name, String email, String phoneNumber, int age) {
//        super();
//    }

//    public Teacher(String id, String name, String email, String phoneNumber, int age) {
//        super();
//    }

//    public Teacher(String id, String name, String email, String phoneNumber, int age) {
//        super();
//    }
//
//    public Teacher(String id, String name, String email, String phoneNumber, int age) {
//        super();
//    }

//    public Teacher(int salary, int experaiceYears){
//        this.salary = salary;
//        this.experaiceYears = experaiceYears;
//    }

    public void setSalary(int salary){
        this.salary = salary;
    }
    public int getSalary(){
        return salary;
    }
    public void setExperaiceYears(int experaiceYears){
        this.experaiceYears = experaiceYears;
    }
    public int getExperaiceYears(){
        return experaiceYears;
    }

}
