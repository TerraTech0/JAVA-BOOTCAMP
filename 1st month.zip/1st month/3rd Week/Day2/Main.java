public class Main {
    public static void main(String[] args) {


//        Student s1 = new Student("1" , "Ahmed", "A@gmail.com", "057383473", 25, 2, 3.9);
//        Student s2 = new Student("2" , "Ali", "Ali@gmail.com", "056854584", 30, 5, 4.8);
//        Student s3 = new Student("3" , "Waleed", "Waleed@gmail.com", "054848724", 23, 1, 2.8);
//        System.out.println("id: "+s1.getAge()+ "\nName: "+ s1.getName()+"\nEmail: "+ s1.getEmail()+"\nPhone Number: "+ s1.getPhoneNumber()
//        +"\nAge: "+s1.getAge()+"\nGPA: "+s1.getGPA());
//        System.out.println("==============================");
//        System.out.println("id: "+s2.getAge()+ "\nName: "+ s2.getName()+"\nEmail: "+ s2.getEmail()+"\nPhone Number: "+ s2.getPhoneNumber()
//        +"\nAge: "+s2.getAge()+"\nGPA: "+s2.getGPA());
//        System.out.println("==============================");
//        System.out.println("id: "+s3.getAge()+ "\nName: "+ s3.getName()+"\nEmail: "+ s3.getEmail()+"\nPhone Number: "+ s3.getPhoneNumber()
//        +"\nAge: "+s3.getAge()+"\nGPA: "+s3.getGPA());
//

        FullTime f1 = new FullTime("4", "Nawaf", "Nawaf@gmail.com",
                "05638438473", 26, 9000, 1, 10);
        f1.setSalary(5000);
        System.out.println("Id: "+f1.getId()+"\nName: "+f1.getName()+"\nEmail: "+f1.getEmail()+"\nPhoneNumber: "+f1.getPhoneNumber()+"\nAge: "+f1.getAge()
        +"\nYears Of Excperance: "+f1.getExperaiceYears()+"\nSalary: "+f1.getSalary()+"\nBouns: "+f1.getBouns());

        PartTime p1 = new PartTime("5", "Abdulrahman", "A@gmail.com",
                "0564836483", 25, 18000, 4, 5);
        p1.setSalary(30);
//        System.out.println("Id: "+p1.getId()+"\nName: "+p1.getName()+"\nEmail: "+ p1.getEmail()+"\nPhone Number: "+p1.getPhoneNumber(), "\nAge: "+p1.getAge()+"\nYears of exp"+
//                p1.getExperaiceYears()+"\nSalary"+p1.getSalary()+"\nhourse: ");
    }
}
