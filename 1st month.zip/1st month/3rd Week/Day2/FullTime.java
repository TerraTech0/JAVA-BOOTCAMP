public class FullTime extends Teacher{
    private double bouns ;

    public FullTime(String id, String name, String email, String phoneNumber, int age, int salary, int experaiceYears, double bouns) {
        super(id, name, email, phoneNumber, age, salary, experaiceYears);
        this.bouns = bouns;

    }

    public void setBouns(double bouns){
        this.bouns = bouns;
    }
    public double getBouns(){
        return bouns;
    }

    @Override
    public void setSalary(int salary) {
        salary += salary * bouns / 100;
        super.setSalary(salary);
    }
}
