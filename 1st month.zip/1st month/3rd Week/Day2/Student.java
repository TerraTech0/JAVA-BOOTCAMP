public class Student extends Person{
    private double GPA;
    private int level;

    public Student(String id, String name, String email, String phoneNumber, int age, int level, double GPA) {
        super(id, name, email, phoneNumber, age);
        // to
        this.level = level;
        this.GPA = GPA;
    }


    public void setGPA(double GPA){
        this.GPA = GPA;
    }
    public double getGPA(){
        return GPA;
    }
    public void setLevel(int level){
        this.level = level;
    }
    public int getLevel(){
        return level;
    }
}
