public class PartTime extends Teacher{
    private int hours;

    public PartTime(String id, String name, String email, String phoneNumber, int age, int salary, int experaiceYears, int hours) {
        super(id, name, email, phoneNumber, age, salary, experaiceYears);
        this.hours = hours;
    }

    public void setHours(int hours){

        this.hours = hours;
    }
    public int getHours(){
        return hours;
    }

    @Override
    public void setSalary(int salary) {
        super.setSalary(hours * 30);
    }
}
