public class Math {
}
