import java.util.ArrayList;
import java.util.Scanner;

public class Methods {
    static Scanner data = new Scanner(System.in);
    public static void main(String[] args) {

//        System.out.println("Enter First number: ");
//        int fnum = data.nextInt();
//        System.out.println("Enter Second number: ");
//        int snum = data.nextInt();
//        System.out.println(mult(fnum, snum));
//        sum();
//        sub(2.2 , 3.5);
//        System.out.println(sum(10, 5)/2);
//        System.out.println(avrage(sum(2, 5),2));
//        System.out.println("Enter number: ");
//        int num = data.nextInt();
//        String[] names = {"Majd", "Maha", "Naha","Najd"};
//        int[] grade = {60, 50, 70, 100, 99};
        System.out.println("Enter your first hoppy: ");
        String hoppy1 = data.nextLine();
        System.out.println("Enter your second hoppy: ");
        String hoppy2 = data.nextLine();
        System.out.println("Enter your third hoppy: ");
        String hoppy3 = data.nextLine();


        System.out.println(q(hoppy1, hoppy2, hoppy3));
    }
    public static int sum(int num1, int num2){
        return num1 + num2;
    }
    public static int avrage(int sum, int num){
        int avrage = sum / num ;
        return avrage;
    }

    public static Double sub (double fnum, double snum){
//        fnum = 1;
//        snum = 2;
        return fnum - snum;
    }
    public static int mult(int fnum, int snum){
        return fnum * snum;
    }


//    public static void check(int num){
//        if (num % 2 == 0) {
//            System.out.println("Odd");
//        }else {
//            System.out.println("Even");
//        }
//    }

    public static void check(String[] names, String letter){

        for (String s:names){
            if (s.contains(letter)){
                System.out.println(s);
            }
        }
    }
    public static void passorfail(int[] grade, int cond){
//        for (int s:grade){
//            if ()
        for(int n: grade){
//            if (){
//
//            }
        }

//        }
    }

    public static ArrayList q(String hoppy1, String hoppy2, String hoppy3){
//        String[] hoppies;
        ArrayList hoppies = new ArrayList();

        hoppies.add(hoppy1);
        hoppies.add(hoppy2);
        hoppies.add(hoppy3);


        return hoppies;
    }






}