import java.util.InputMismatchException;
import java.util.Scanner;

public class Day3 {
    static Scanner data = new Scanner(System.in);

    public static void main(String[] args){
//        Exceptions();

//        System.out.println("Please Enter your salary");
//        int salary = data.nextInt();
//        //When i enter this code below? i should call throws in header.
////        checkSalary(salary);
//        try {
//            checkSalary(salary);
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }

        //Calculate the age if more than 18 will print welcome if under than 18 it will print under age.
//        int age;
//        try {
//            System.out.println("Enter your age: ");
//            age = data.nextInt();
//            checkAge(age);
//        } catch (InputMismatchException e) {
//            System.out.println("Enter number");
//        } catch (Exception e2) {
//            System.out.println(e2.getMessage());
//        } finally {
//            System.out.println("Working..");
//        }


    }

    public static void exceptions() {
        //        int age;
//        int num1;
//        int num2;
//        System.out.println("Enter your age");
//        try {
//            age = data.nextInt();
//            System.out.print(age);
//            System.out.println("your age is: " + age);
//
//            System.out.print("Enter first number: ");
//            num1 = data.nextInt();
//            System.out.print("Enter second number: ");
//            num2 = data.nextInt();
//            System.out.println(num1 / num2);
//
//            System.out.print("Enter index: ");
//            int[] arr = {1, 2, 3};
//            System.out.println(arr[2]);
//        } catch (InputMismatchException e) {
//            System.out.println("Enter the right input (number).");
//        } catch (ArithmeticException e2) {
//            System.out.println(e2.getMessage());
//        } catch (ArrayIndexOutOfBoundsException e3) {
//            System.out.println(e3.getMessage());
//        } catch (Exception eBoss){
//            System.out.println(eBoss.getMessage());
//        }
//        finally {
//            System.out.println("This always working.");
//        }
//            System.out.println("Working!!");
//        }

        String word;
        int index;
        try {
            System.out.println("Enter the word: ");
            word = data.nextLine();
            System.out.println("Enter the index: ");
            index = data.nextInt();
            System.out.println(word.charAt(index));
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println(e.getMessage());
        } catch (InputMismatchException e2) {
            System.out.println("You Must Enter a Number");
        } catch (Exception e3) {
            System.out.println(e3.getMessage());
        } finally {
            System.out.println("The Program End");
        }
    }
//    public static void throwAndthrows(){
//
//
//    }

    //Throws always in header liks>> throws Exception
    //Throw i am creating and exception right now like:
    // throw new Exception("invalid salary, enter salary greater than 2000SR");

    /*
    When i enter an throw in method...etc
     */
    public static void checkSalary(int salary) throws Exception {
//        try {
        if (salary < 2000) {
            throw new Exception("invalid salary, enter salary greater than 2000SR");
        }
//        }catch (Exception e){
//            System.out.println(e.getMessage());
//        }

    }

    public static void checkAge(int age) throws Exception{
//        try{
            if(age < 18){
                throw new Exception("Your under age:");
            }else {
                System.out.println("Welcome");
            }
//        }catch (InputMismatchException e){
//            System.out.println(e.getMessage());
//        }finally {
//            System.out.println("Working...");
//        }


    }
}