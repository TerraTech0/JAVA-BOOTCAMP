Create Calculator in Java that’s used to calculate addition, subtraction, multiplication, division, modulus, min, max, average of numbers.  

Display a menu to the user that’s contains the following options:  

  

- Enter 1 to addition the numbers  

  

- Enter 2 to subtraction the numbers  

  

- Enter 3 to multiplication the numbers  

  

- Enter 4 to division the numbers  

  

- Enter 5 to modulus the numbers  

  

- Enter 6 to find minimum number  

  

- Enter 7 to find maximum number  

  

- Enter 8 to find the average of numbers  

  

- Enter 9 to print the last result in calculator  

  

- Enter 10 to print the list of all results in calculator  

  

The program must accept two numbers and operation from the user  

  

Provide option to exit calculator program, if user wants to exit 

  

use methods
