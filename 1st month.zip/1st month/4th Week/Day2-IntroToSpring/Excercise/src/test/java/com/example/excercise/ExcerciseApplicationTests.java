package com.example.excercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
