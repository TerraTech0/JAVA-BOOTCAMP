package com.example.spring;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorld {

    //small api..

    //mapping   //URL
    @GetMapping(path = "/hello")
    //Method
    public String helloWorld(){
        return "HelloWorld";
    }
    //Mapping
    //URL

}
