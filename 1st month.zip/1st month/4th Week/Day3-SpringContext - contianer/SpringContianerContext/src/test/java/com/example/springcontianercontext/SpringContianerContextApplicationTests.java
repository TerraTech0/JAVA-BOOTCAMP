package com.example.springcontianercontext;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringContianerContextApplicationTests {

    @Test
    void contextLoads() {
    }

}
