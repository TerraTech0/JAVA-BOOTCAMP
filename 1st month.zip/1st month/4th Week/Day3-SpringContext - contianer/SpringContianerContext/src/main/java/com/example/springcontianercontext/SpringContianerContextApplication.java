package com.example.springcontianercontext;

import org.apache.catalina.util.ToStringUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

@SpringBootApplication
public class SpringContianerContextApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringContianerContextApplication.class, args);
    }


    //if the qualifier

//    @Qualifier("3")
//    @Bean //use any method inside contianer
//    public String message1(){
//        System.out.println("hey from message1");
//        return "1";
//    }
//    @Bean
//    public String message2(@Qualifier("1")String data){
//        System.out.println(data);
//        return "2";
//    }
//    @Bean
////    @Qualifier("1")
//    @Qualifier("1")
//    public String message3(){
//        System.out.println("hey from message3");
//        return "3";
//    }
//
//    @Bean
//    public String message4(@Qualifier("2") String data){
//        System.out.println("hey from message4");
//        return "4";
//    }

    @Bean
    @Qualifier("1")
    public String getMessage1(){
        System.out.println("hey from message1");
        return "1";
    }
    @Bean
    @Qualifier("2")
    public String getMessage2(@Qualifier("3") String data){
        System.out.println("hey from message2");
        return data;
    }
    @Bean
    @Qualifier("3")
    public String getMessage3(){
        System.out.println("hey from message3");
        return "3";
    }


}
