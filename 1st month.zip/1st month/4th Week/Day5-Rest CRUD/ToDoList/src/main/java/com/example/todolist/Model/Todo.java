package com.example.todolist.Model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data //doing setters and getters
@AllArgsConstructor // doing constructors
public class Todo {

    private String title;
    private boolean status;


}
