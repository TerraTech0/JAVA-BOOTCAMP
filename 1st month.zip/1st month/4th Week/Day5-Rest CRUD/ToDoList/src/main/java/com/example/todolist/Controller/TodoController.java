package com.example.todolist.Controller;

import com.example.todolist.Api.ApiResponse;
import com.example.todolist.Model.Todo;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1/todo") //choose the begining the path ,, v1 = version1. ,, api = request & respons.
public class TodoController {

    //doing CRUD
    //why do we create arraylist? >> it's virtual database.
    ArrayList<Todo> todos = new ArrayList<>();
    /*
    get
    post
    update
    delete
     */
    @GetMapping("/get")
    public ArrayList<Todo> getTodos(){
        return todos;
    }


    /*
    // if i let this path impety it will work but the path will be the (api,v1,To do)
     */
    @PostMapping("/add")
    public ApiResponse addTodo(@RequestBody Todo todo){ //the datatype here is object
        todos.add(todo);

        return new ApiResponse("todo added successfully");
    }

    // like in social media >> can be put or post
    // search must be getmapping
//    @PutMapping("/update/{index}")
//    public String updatedTodo(@PathVariable int index, @RequestBody Todo todo){
//        todos.set(index, todo);
//        return "todo updated successfully";
//    }

    @PutMapping("/update/{index}")
    public ApiResponse updatedTodo(@PathVariable int index, @RequestBody Todo todo){
        todos.set(index, todo);
        return new ApiResponse("todo updated successfully");
//        return "todo updated successfully";
    }

    @DeleteMapping("/delete/{index}")
    public ApiResponse deleteTodo(@PathVariable int index){
        todos.remove(index);
        return  new ApiResponse("Deleted Successfuly");
//        return "Deleted Successfuly";
    }

}
