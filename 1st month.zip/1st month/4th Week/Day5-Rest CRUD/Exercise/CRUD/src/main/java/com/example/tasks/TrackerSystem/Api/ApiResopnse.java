package com.example.tasks.TrackerSystem.Api;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ApiResopnse {
    private String message;
}
