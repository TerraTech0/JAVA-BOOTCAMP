package com.example.review.Controller;

import com.example.review.ApiResponse.ApiResponse;
import com.example.review.Model.Review;
import com.example.review.Service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.apache.coyote.Response;
import org.springframework.boot.system.ApplicationPid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;


    @GetMapping("/get")
    public ArrayList<Review> getReviews(){
        return reviewService.getReviews();
    }

    @PostMapping("/add")
    public ResponseEntity addReview(@RequestBody @Valid Review review, Errors errors){
        if (errors.hasErrors()){
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        reviewService.addReview(review);
        return ResponseEntity.status(200).body(new ApiResponse("Review added successfully!"));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updateReview(@PathVariable int id, @RequestBody @Valid Review review, Errors errors){
        if (errors.hasErrors()){
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        reviewService.updateReview(id, review);
        return ResponseEntity.status(200).body(new ApiResponse("reviews updated successfully!"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteReview(@PathVariable int id){
        reviewService.deleteReview(id);
        return ResponseEntity.status(200).body(new ApiResponse("review deleted successfully!"));
    }

}
