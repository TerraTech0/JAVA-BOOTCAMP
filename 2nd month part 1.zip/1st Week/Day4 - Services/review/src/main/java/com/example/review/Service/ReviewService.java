package com.example.review.Service;

import com.example.review.Model.Review;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ReviewService {

    ArrayList<Review> reviews = new ArrayList<>();


    public ArrayList<Review> getReviews(){
        return reviews;
    }

    public void addReview(Review review){
        reviews.add(review);
    }

    public boolean updateReview(int id, Review review){
        for (int i = 0; i < reviews.size(); i++) {
            if (reviews.get(i).getId() == id){
                reviews.set(i, review);
                return true;
            }
        }
        return false;
    }

    public boolean deleteReview(int id){
        for (int i = 0; i < reviews.size(); i++) {
            if (reviews.get(i).getId() == id){
                reviews.remove(i);
                return true;
            }
        }
        return false;
    }

}
