package com.example.review.Model;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Review {

    @NotNull(message = "id can't be null")
    private int id;

    @NotEmpty(message = "name can't be empty!")
    private String name;

    @NotNull(message = "age can't be null")
    @Min(value = 18, message = "age must be +18")
    private int age;

    @NotEmpty
    @Pattern(regexp = "^(CS|Newtwork|CyberSecurity)$")
    private String college;
}
