package com.example.services.Controller;

import com.example.services.ApiResponse.ApiResponse;
import com.example.services.Model.Blog;
import com.example.services.Service.BlogService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.coyote.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1/blog")
@RequiredArgsConstructor
public class BlogController {

    private final BlogService blogService; //dependancy injuction


    @GetMapping("/show")
    public ResponseEntity getBlogs(){
//        ArrayList<Blog> blogs = blogService.getBlogs();
//        return ResponseEntity.status(200).body(blogs);
        return ResponseEntity.status(200).body(blogService.getBlogs());

    }


    @PostMapping("/add")
    public ResponseEntity addBlogs(@RequestBody @Valid Blog blog, Errors errors){
        if (errors.hasErrors()){
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }

        blogService.addBlog(blog);
        return ResponseEntity.status(200).body(new ApiResponse("blog added!"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteBlog(@PathVariable int id){
        boolean isDeleted = blogService.deleteBlog(id);
        if (isDeleted){
            return ResponseEntity.status(200).body(new ApiResponse("blog removed!"));
        } else {
            return ResponseEntity.status(400).body(new ApiResponse("blog not found!"));
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updateBlog(@PathVariable int id, @RequestBody @Valid Blog blog, Errors errors){
        if (errors.hasErrors()){
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        blogService.updateBlog(id, blog);
        return ResponseEntity.status(200).body(new ApiResponse("Blog updated successfully!"));

    }

    @GetMapping("/get/{title}")
    public ResponseEntity searchBlog(@PathVariable String title){
        Blog blog = blogService.searchByTitle(title);
        if (blog != null){
            return ResponseEntity.status(200).body(blog);
        }
        return ResponseEntity.status(400).body(new ApiResponse("title not found!"));
    }

//    @GetMapping("/get/{id}")
//    public ResponseEntity searchById(@PathVariable int id){
//        ArrayList<Blog> blog = blogService.searchById(id);
//        if (blog != null){
//            return ResponseEntity.status(200).body(blog);
//        }
//        return ResponseEntity.status(400).body(new ApiResponse("id not found!"));
//    }

//    public ResponseEntity searchById(@PathVariable int id){
//        Blog blog = blogService.searchById(id);
//
//    }
}
