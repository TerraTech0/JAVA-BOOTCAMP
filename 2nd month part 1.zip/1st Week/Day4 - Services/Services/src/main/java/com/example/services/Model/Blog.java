package com.example.services.Model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Blog {

    @NotNull(message = "id can't be null!")
    private int id;
    @NotEmpty(message = "title can't be empty!")
    private String title;
    @NotEmpty(message = "body can't be empty!")
    @Size(min = 10, max = 4000, message = "body can't be more than 4000 charachters")
    private String body;
}
