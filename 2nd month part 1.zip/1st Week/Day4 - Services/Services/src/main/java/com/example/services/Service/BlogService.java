package com.example.services.Service;

import com.example.services.Model.Blog;
import org.springframework.stereotype.Service;

import java.awt.image.RescaleOp;
import java.util.ArrayList;

@Service
public class BlogService {
    ArrayList<Blog> blogs = new ArrayList<>();

    public ArrayList<Blog> getBlogs(){
        return blogs;
    }

    public void addBlog(Blog blog){
        blogs.add(blog);
    }


    public boolean deleteBlog(int id){
        for (int i = 0; i < blogs.size(); i++) {
            if (blogs.get(i).getId() == id){
               blogs.remove(i);
               return true;
            }
        }
        return false;
    }

    public boolean updateBlog(int id, Blog blog){
        for (int i = 0; i < blogs.size(); i++) {
            if (blogs.get(i).getId() == id){
                blogs.set(i, blog);
                return true;
            }
        }
        return false;
    }

    // in for loop :
//    public ArrayList<Blog> searchBlog(String title){
//        ArrayList<Blog> blog = blogs;
//        for (int i = 0; i < blogs.size(); i++) {
//            if (blogs.get(i).getTitle().equalsIgnoreCase(title));
//            return blog;
//        }
//        return null;
//    }

    // in foreach :
    public Blog searchByTitle(String title){
        for (Blog blog : blogs){
            if (blog.getTitle().equalsIgnoreCase(title))
            {
                return blog;
            }
        }
        return null;
    }


//    public Blog searchById(int id){
//        for (Blog blog : blogs){
//            if (blog.getId() == id){
//                return blog;
//            }
//        }
//        return null;
//    }
    public ArrayList<Blog> searchById(int id){
        ArrayList<Blog> blog = new ArrayList<>();
        for (int i = 0; i < blogs.size(); i++) {
            if (blogs.get(i).getId() == id){
                blog.get(i);
            }
        }
        return blog;
    }


}
