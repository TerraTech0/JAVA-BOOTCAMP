package com.example.validation.Controller;

import com.example.validation.ApiResponse.ApiResponse;
import com.example.validation.Model.User;
import jakarta.validation.ReportAsSingleViolation;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1/user")
public class UserController {

    ArrayList<User> users = new ArrayList<>();

    @GetMapping("/get")
    public ResponseEntity getUsers(){
        return ResponseEntity.status(HttpStatus.OK).body(users);
        //or
//        return ResponseEntity.status(200).body(users);
    }

    @PostMapping("/add")
    public ResponseEntity addUsers(@RequestBody @Valid User user, Errors errors){
        if (errors.hasErrors()){
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }

        users.add(user);
        return ResponseEntity.status(200).body(new ApiResponse("user added"));
    }

    @PutMapping("/update/{index}")
    public ResponseEntity updateUser(@PathVariable int index, @RequestBody @Valid User user, Errors errors){
        if (errors.hasErrors()){
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        users.set(index, user);
        return ResponseEntity.status(200).body(new ApiResponse("user updated"));
    }

    @DeleteMapping("/delete/{index}")
    public ResponseEntity deleteUser(@PathVariable int index){
        users.remove(index);
        return ResponseEntity.status(200).body(new ApiResponse("user deleted"));
    }


    //search by username
    @GetMapping("/search/{name}")
    public ResponseEntity searchByUsername(@PathVariable String name){
        for (User user : users){
            if (user.getUsername().equals(name)){
                return ResponseEntity.status(200).body(users);
            }
        }
        return ResponseEntity.status(400).body(new ApiResponse("name not found!"));
    }

    //return list of object that has age
    @GetMapping("/search/age/{age}")
    public ResponseEntity searchForAge(@PathVariable int age){

        ArrayList<User> usersAge = new ArrayList<>();

        for (User user : users){
            if (user.getAge()>= age)
            usersAge.add(user);
        }
        if (usersAge.isEmpty()){
            return ResponseEntity.status(400).body(new ApiResponse("No user found"));
        }else {
            return ResponseEntity.status(200).body(usersAge);
        }
    }





}