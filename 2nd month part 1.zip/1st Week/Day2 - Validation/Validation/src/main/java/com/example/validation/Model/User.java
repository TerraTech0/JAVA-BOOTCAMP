package com.example.validation.Model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class User {

    @NotEmpty(message = "username should be not empty!") // it has contain on message
    @Size(min = 4, max = 10, message = "username should be between 4 and 10 charachters")
    private String username;

    @NotEmpty(message = "password should be not empty!")
//    @Pattern(regexp = "\n^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#&()–[{}]:;',?/*~$^+=<>]).{8,20}$\n")
    private String password;

    @NotNull(message = "age should be not empty!")
    @Min(value = 18, message = "age should be 18 and more")
    private Integer age;

    @Email
    private String email;
}
